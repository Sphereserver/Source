This world files contains spawns/items for Felluca, Ilshenar and Malas.
I didn't add Trammel and Tokuno cause I wasn't sure if you'd use it.

REMEMBER TO UNCOMMENT THE MAP SCRIPTS ON SPHERETABLES IF USING THIS!

by ClouD_BR