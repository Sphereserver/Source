To activate Doom Dungeon just type .generatedoom
To get more infos about this system visit this webpage: http://uo.stratics.com/content/atlas/doom.php

Note: To fully activate the doom artifacts (with slayers) you need to add also the Slayer_Weapons script.

By Cloud_BR