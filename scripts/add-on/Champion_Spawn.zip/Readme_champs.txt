This is an exact copy of OSI's champion system, for sphere =D

To activate the champions (in the exact places like on OSI) type .GENERATECHAMPS.
Make sure that the Star Chamber is empty (it's the place for the Harrower altar).
After that, just enjoy =)

Notes & Instructions: The system will work with any ini setting, but I suggest (just to make it more beautifull) to activate
tooltips and the new triggers (with the new triggers you'll activate the champions habilities).

You'll probably have to increase MaxComplexety in sphere.ini to allow more npcs on a sector.
And also, remember to activate at least Felucca and Ilshenar, or you might have some errors.

Check the defs in the script for customization.

You can acess a customization menu by double clicking the idol with .gm on, and you can create blank champ altars by using
.CREATEALTAR

by ClouD_BR