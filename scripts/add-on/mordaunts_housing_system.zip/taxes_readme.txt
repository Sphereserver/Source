Taxes & Fees: (or.. how to remove money from your economy without a riot)


Property Tax (previously called Maintenance):

To turn on set the DEFNAME property_tax to a figure other than 0 (by default it is set to 10)
This figure is the percentage of the HOUSE VALUE that it will cost players to refresh their house each period as set in DEFNAME can_decay.
This percentage rate can be overridden on a regional basis by setting region.tag.maintenance_override in a region of your chosing.
If a house is placed in a region where region.tag.maintenance_override exists, property tax will be charged an that percentage of HOUSE VALUE.
region.tag.maintenance_override may be higher or lower than the default DEFNAME property_tax

Estate Tax: (new for v2.2 coming soon)

Once a player has more than DEFNAME estate_tax they become subject to additional fees each month to refresh EVERY house.
These fees are based upon the number entered into DEFNAME estate_rate which is again a percentage of the HOUSE VALUE
This percentage is also overridden by any region.tag.maintenance_override for the region in which the house was placed.
By default this setting is NOT active when you download the script. Change DEFNAME estate_tax to a number greater than zero (3 is nice) to turn it on.
If DEFNAME account_house_limit is set to a number other than zero, this number being the hard limit on the number of houses allowed PER ACCOUNT, then DEFNAME estate_tax must be set to a value lower for it to come into effect.

There are 2 scales for estate tax, this is set in DEFNAME estate_calc.
If DEFNAME estate_calc is set to 1, a player is subject to estate tax on a flat rate based upon DEFNAME estate_rate or region.tag.maintenance_override should it exist.
In setting 1 players can own as many houses as they wish and only realistically have to pay twice what they would pay without estate tax. This setting is cheaper for player with lots of houses.
If DEFNAME estate_calc is set to 2, a player is subjecy to estate tax on a linear scale based upon DEFNAME estate_rate or region.tag.maintenance_override should it exist.
In setting 2 a player with 1 house over the DEFNAME estate_tax would have to pay twice the amount they would normally pay without estate tax. With 2 houses over the DEFNAME estate_tax they would have to pay 3 times the amount, and so on... This setting is cheaper for players with fewer houses.

Buying extra secure storage & co-owner/friend slots:

If DEFNAME buy_storage is set to 1 players will be able to purchase extra secure storage slots for their house.
If DEFNAME buy_increased_list is set to 1 players will be able to purchase extra friend/co-owner slots for their house.
A player purchasing either of these increases the HOUSE VALUE which also affects how much property tax (and estate tax if applicable) they have to pay each month.

The prices for extra co-owners and friends can be set in DEFNAME xtra_co-owner_price and DEFNAME xtra_friend_price respectively.
The price for extra secure storage is calculated automatically based on the original value of the house.

Redeeding:

The cost for a player to redeed their house can be set in DEFNAME redeed_fee where the value is a percentage of the HOUSE VALUE
Demolishing a house without redeeding is free of charge and will refund players the HOUSE VALUE for the building that was demolished.

Any upgrades (which includes construction on custom houses) will be refunded to the player minus the DEFNAME redeed_fee where applicable. If no refund exists or it does not entirely cover the DEFNAME redeed_fee, the player will be charged the remainder.