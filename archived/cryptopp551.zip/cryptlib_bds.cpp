//---------------------------------------------------------------------------

/*
#include <vcl.h>
#pragma hdrstop
*/
#define Library

// To add a file to the library use the Project menu 'Add to Project'.

