// ExtractKeys.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

void readEntireFile(FILE *fp, char *&data, size_t &size) 
{
	fseek(fp, 0, SEEK_END);
	size = ftell(fp);
	data = (char*)malloc(size);
	fseek(fp, 0, SEEK_SET);	

	size_t offset = 0;
	size_t readSize = ~0;

	while (readSize != 0) 
	{
		readSize = fread(data + offset, 1, 4096, fp);
		offset += readSize;
	}
}

bool searchClientKeys(char *data, size_t size, int &key1, int &key2) 
{
	if (size < 100) 
	{
		return false;
	}

	// What we expect:
	/*
	:0041AA2F C1E61F                  shl esi, 1F
	:0041AA32 D1E8                    shr eax, 1
	:0041AA34 0BC6                    or eax, esi
	:0041AA36 47                      inc edi
	:0041AA37 3305BC296B00            xor eax, dword[006B29BC]
	*/

	int iAddress1;
	int iAddress2;

	for (size_t i = 0; i < size - 100; ++i) 
	{
		// Check the given position
		unsigned char *pos = (unsigned char*)data + i;

		// -----------
		// shl esi, 1F
		if ( *(pos++) != 0xC1 )
			continue;

		if (*pos < 0xe0 || *pos > 0xe7)
			continue;

		unsigned char shlRegister = (*pos) & 0xF;
		pos++;

		if (*(pos++) != 0x1f)
			continue;

		// -----------
		// shr eax, 1
		if ( *(pos++) != 0xD1 )
			continue;

		if ((*pos & 0xe8) != 0xe8)
			continue;

		unsigned char shrRegister = (*pos) & 0x7;
	
		if ( shlRegister == shrRegister )
			continue;

		pos++;

		// -----------
		// or eax, esi
		if (*(pos++) != 0x0B)
			continue;

		if ((*pos & 0xC0) != 0xC0) // Check for register extension byte
			continue;

		char orOperand1 = (*pos >> 3) & 7;
		char orOperand2 = *pos & 7;

		if ((orOperand2 == shlRegister) && (orOperand1 == shrRegister))
		{
			pos++;

			// -----------
			// inc edi
			if ((*pos & 0xF0) != 0x40)
				continue;

			if ((*pos & 0x40) != 0x40) // Check for register extension byte
				continue;

			pos++;
			// -----------
			// xor eax, dword[006B29BC]
			if (*(pos++) != 0x33)
				continue;

			if ((*pos == 0x05) && (shrRegister == 0)) // EAX
				goto getaddress1;

			if ((*pos == 0x0D) && (shrRegister == 1)) // ECX
				goto getaddress1;

			if ((*pos == 0x15) && (shrRegister == 2)) // EDX
				goto getaddress1;

			if ((*pos == 0x1D) && (shrRegister == 3)) // EBX
				goto getaddress1;

			if ((*pos == 0x35) && (shrRegister == 6)) // ESI
				goto getaddress1;

			if ((*pos == 0x3D) && (shrRegister == 7)) // EDI
				goto getaddress1;

			continue;

getaddress1:
			pos++;
			iAddress1 = pos[0] | (pos[1] << 8) | (pos[2] << 16) | (pos[3] << 24);
			iAddress2 = iAddress1 - 4;

			key1 = iAddress1;
			key2 = iAddress2;

			return true; // We reached a successfull pattern match
		}
	}

	return false;
}

bool readFromClientMemory(_TCHAR* data, int &key1, int &key2)
{
	char ClientPath[4096], ThisPath[4096];
	STARTUPINFO si;
	PROCESS_INFORMATION pi;

	memset(&si, 0, sizeof(si));
	memset(&pi, 0, sizeof(pi));
	si.cb = sizeof(si);

	::GetCurrentDirectory(4096, ClientPath);
	::GetCurrentDirectory(4096, ThisPath);
	strcat(ThisPath, "\\");
	strcat(ThisPath, data);

	if( ::CreateProcess(ThisPath, NULL, NULL, NULL, FALSE, 0, NULL, ClientPath, &si, &pi) )
	{
		byte * buffer = new byte[4];
		DWORD bufferLenght;
		int address1 = key1;
		int address2 = key2;
		key1 = 0; key2 = 0;

		::Sleep(3000);
		if ( ::ReadProcessMemory( pi.hProcess, (void*)address1, buffer, (size_t)4, &bufferLenght ) )
		{
			key1 = buffer[0] | (buffer[1] << 8) | (buffer[2] << 16) | (buffer[3] << 24);
			memset(buffer, 0, 4);
			bufferLenght = 0;

			if ( ::ReadProcessMemory( pi.hProcess, (void*)address2, buffer, (size_t)4, &bufferLenght ) )
			{
				key2 = buffer[0] | (buffer[1] << 8) | (buffer[2] << 16) | (buffer[3] << 24);
			}
		}

		::TerminateProcess( pi.hProcess, 0 );
	}
	else
		return false;

	if (( key1 == 0 ) && ( key2 == 0 ))
		return false;
	
	return true;
}


int _tmain(int argc, _TCHAR* argv[])
{
	if (argc == 1)
	{
		printf("Usage: %s <client.exe>\n", argv[0]);
		return -1;
	}

	// Treat argv[0] as the filename and slurp the file into memory
	size_t fileSize;
	char *fileData;

	FILE *fp = fopen(argv[1], "rb");

	if (!fp) 
	{
		printf("Couldn't open %s for reading.\n", argv[1]);
	}
	else
	{
		readEntireFile(fp, fileData, fileSize);
		printf("Client Size: %u\n", fileSize);

		int key1, key2;
		bool bResultSearch = searchClientKeys(fileData, fileSize, key1, key2);
		free(fileData); fclose(fp);

		if (bResultSearch)
		{
			printf("Found client areas: 0x%x, 0x%x.\n", key1, key2);
			if ( readFromClientMemory(argv[1], key1, key2) )
			{
				printf("Found client keys: 0x%x, 0x%x.\n", key1, key2);
			}
			else
			{
				printf("Unable to find encryption keys/launch client.exe.\n");
			}
		} 
		else 
		{
			printf("Unable to find encryption keys.\n");
		}

		system("pause");
	}

	return 0;
}

