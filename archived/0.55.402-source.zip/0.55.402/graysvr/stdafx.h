//
// stdafx.h
//
// header for shared files.

#include "graysvr.h"	// predef header.

