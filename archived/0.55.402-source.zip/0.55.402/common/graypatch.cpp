#ifdef _WIN32
#include "stdafx.h"
#include "graypatch.h"
#endif

