#define GRAY_VERSION	"0.55 R4.0.2.a"		// share version with all files.
