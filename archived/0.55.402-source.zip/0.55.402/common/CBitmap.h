//
// CBITMAP.H
// Copyright Menace Software (www.menasoft.com).
//

#ifndef _INC_CBITMAP_H
#define _INC_CBITMAP_H
#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


#endif // _INC_CBITMAP_H
