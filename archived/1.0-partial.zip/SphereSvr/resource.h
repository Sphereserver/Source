//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SphereSvr.rc
//
#define IDR_MAINFRAME                   100
#define IDR_ABOUT_BOX                   101
#define IDM_POP_TRAY                    102
#define IDM_POP_LOG                     103
#define IDM_CONFIG                      156
#define IDC_STAT_STATS                  201
#define IDC_STAT_CLIENTS                202
#define IDC_O_LOG_LEVEL                 250
#define IDC_O_LOG_CLIENTS               251
#define IDC_O_LOG_GM_CMDS               252
#define IDC_O_LOG_GM_PAGES              253
#define IDC_O_LOG_SPEAK                 254
#define IDM_OPTIONS                     512
#define IDM_RESTORE                     544
#define IDM_MINIMIZE                    560
#define IDM_EDIT_COPY                   580
#define IDM_EXIT                        582
#define IDC_ABOUT_VERSION               1117
#define IDC_ABOUT_MENASOFT_LINK         1118
#define IDC_ABOUT_SPHERE_LINK           1119
#define IDC_SETUP_PORT                  4020
#define IDC_SETUP_SCRIPTS               4021
#define IDC_SETUP_SAVE                  4022
#define IDC_SETUP_LOG                   4023
#define IDC_SETUP_NAME                  4024
#define IDM_RESYNC_PAUSE                32784

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        157
#define _APS_NEXT_COMMAND_VALUE         32785
#define _APS_NEXT_CONTROL_VALUE         4026
#define _APS_NEXT_SYMED_VALUE           210
#endif
#endif
