//
// CServResource.cpp
//

