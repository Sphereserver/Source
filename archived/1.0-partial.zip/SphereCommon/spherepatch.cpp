#ifdef _WIN32
#include "stdafx.h"
#include "spherepatch.h"
#endif

