//##############################################################################################################//
#include "CmnHdr.h"

#include <windows.h>
#include <process.h>
#include <tchar.h>
#include <Winsock2.h>

//###############################################################################################################//
#pragma comment( lib, "ws2_32" )

//###############################################################################################################//
#define THREADS 10

//###############################################################################################################//
CHAR szServerIP[32] = {0};
volatile LONG g_fContinue = 1;

//###############################################################################################################//
VOID LogError( PSTR pszFunc, DWORD dwError )
{
    HANDLE hFile = CreateFile( T("EchoClient.err"), GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ, NULL, 
						       OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL );
    if( hFile == INVALID_HANDLE_VALUE ){ return; }

    SetFilePointer( hFile, 0, NULL, FILE_END );

    CHAR szError[32] = {0};
    wsprintfA( szError, "%s: %d\r\n", pszFunc, dwError );

	DWORD dwWrite = 0;
	WriteFile( hFile, szError, lstrlenA( szError ), &dwWrite, NULL );

    CloseHandle( hFile );
}

//###############################################################################################################//
DWORD WINAPI Thread( PVOID pvSome )
{
    BYTE         bBuffer[BUF_SIZE] = {0};
    SOCKET       Socket            = INVALID_SOCKET;
    sockaddr_in  server            = {0};
    hostent     *host              = NULL;
    int          iRet              = 0;

    server.sin_family      = AF_INET;
    server.sin_port        = htons( 6060 ); // Port.
    server.sin_addr.s_addr = inet_addr( szServerIP );

    while( g_fContinue ){
        __try{
            Socket = socket( AF_INET, SOCK_STREAM, IPPROTO_TCP );
            if( INVALID_SOCKET == Socket ){
                LogError( "socket()", WSAGetLastError() );
                __leave;
                }

            if( connect( Socket, (sockaddr*) &server, sizeof( server ) ) == SOCKET_ERROR ){
                LogError( "connect()", WSAGetLastError() );
                __leave;
                }

            // Send 1Kb.
            iRet = send( Socket, (char*) bBuffer, 1024, 0 );
            if( SOCKET_ERROR == iRet ){
                LogError( "send()", WSAGetLastError() );
                __leave;
                }

            iRet = recv( Socket, (char*) bBuffer, BUF_SIZE, 0 );
            if( SOCKET_ERROR == iRet ){
                LogError( "recv()", WSAGetLastError() );
                __leave;
                }
            }
        __finally{
            if( Socket != INVALID_SOCKET ){
                shutdown( Socket, SD_BOTH );
                closesocket( Socket );
                Socket = INVALID_SOCKET;
                }
            }
        }

    return 0;
}

//##############################################################################################################//
int WINAPI _tWinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow )
{
    int iArgc = 0;
    PWSTR *ppArgv = (PWSTR*) CommandLineToArgvW( GetCommandLine(), &iArgc );

    if( 1 == iArgc ){
        MessageBox( NULL, T("Usage: EchoClient.exe <ServerIP>"), T("EchoClient"), MB_OK );
        return 0;
        }

    WideCharToMultiByte( CP_ACP, 0, ppArgv[1], -1, szServerIP, sizeof( szServerIP ), NULL, NULL );

	WSADATA wsd = {0};
    WSAStartup( MAKEWORD( 2,2 ), &wsd );

    HANDLE hThreads[THREADS] = {0};

    // Start 10 threads.
    for( int i = 0; i < THREADS; i++ ){
        hThreads[i] = BEGINTHREAD( Thread, NULL );
        }

    MessageBox( NULL, T("Close EchoClient"), T("EchoClient"), MB_OK );

    InterlockedExchange( &g_fContinue, 0 );

    WaitForMultipleObjects( THREADS, hThreads, TRUE, INFINITE );

    for( int i = 0; i < THREADS; i++ ){
        CloseHandle( hThreads[i] );
        }

    WSACleanup();

    return 0;
}

//##############################################################################################################//