//##############################################################################################################//
#include "PServer.h"

//##############################################################################################################//
class CPServer{
    public:
        DWORD Start( PPSERVERPARAM pParam ){ return PServer_Start( pParam ); }
        VOID  Stop(){ PServer_Stop(); }
        DWORD PostRecv( PCONNECTION pConnection, PBYTE pbBuffer, DWORD dwSize, PVOID pvPerIoUserData ){ return PServer_PostRecv( pConnection, pbBuffer, dwSize, pvPerIoUserData ); }
        DWORD PostSend( PCONNECTION pConnection, PBYTE pbBuffer, DWORD dwSize, PVOID pvPerIoUserData ){ return PServer_PostSend( pConnection, pbBuffer, dwSize, pvPerIoUserData ); }
        VOID  CloseConnection( PCONNECTION pConnection ){ PServer_CloseConnection( pConnection ); }
        VOID  QueryInformation( PINFORMATION pInformation ){ PServer_QueryInformation( pInformation ); }
        VOID  EnableConnectionIdleCheck( PCONNECTION pConnection, BOOL fEnable ){ PServer_EnableConnectionIdleCheck( pConnection, fEnable ); }
        VOID  EnumConnections( ENUMCONNECTIONSPROC pEnumConnectionsProc, PVOID pvParam ){ PServer_EnumConnections( pEnumConnectionsProc, pvParam ); }
};

//##############################################################################################################//