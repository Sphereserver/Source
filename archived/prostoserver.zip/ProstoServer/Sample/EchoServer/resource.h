//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by EchoServer.rc
//
#define ID_BUTTON_START                 3
#define ID_BUTTON_STOP                  4
#define IDD_DIALOG_MAIN                 101
#define ID_STATIC_STATUS                1001
#define ID_STATIC_CPUUSAGE              1002
#define ID_STATIC_THREADS               1003
#define ID_CHECK_ONTOP                  1004
#define ID_STATIC_IOLEN                 1005
#define ID_STATIC_CONNECTIONS           1006
#define ID_STATIC_ONCONNECT             1007
#define ID_STATIC_ONDISCONNECT          1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
