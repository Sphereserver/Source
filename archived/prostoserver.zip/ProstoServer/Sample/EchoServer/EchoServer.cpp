//##############################################################################################################//
#include "CmnHdr.h"

#include <windows.h>
#include <windowsX.h>
#include <tchar.h>

#include "CPServer.h"
#include "resource.h"

//##############################################################################################################//
CPServer PServer; // ProstoServer class.

HWND g_hwndMain           = NULL;
BOOL g_fStarted           = FALSE;
LONG g_lOnConnectCount    = 0;
LONG g_lOnDisconnectCount = 0;

//##############################################################################################################//
//##############################################################################################################//
//##############################################################################################################//
VOID LogError( PSTR pszFunc, DWORD dwError )
{
    HANDLE hFile = CreateFile( T("EchoServer.err"), GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ, NULL, 
						       OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL );
    if( hFile == INVALID_HANDLE_VALUE ){ return; }

    SetFilePointer( hFile, 0, NULL, FILE_END );

    CHAR szError[32] = {0};
    wsprintfA( szError, "%s: %d\r\n", pszFunc, dwError );

	DWORD dwWrite = 0;
	WriteFile( hFile, szError, lstrlenA( szError ), &dwWrite, NULL );

    CloseHandle( hFile );
}

//###############################################################################################################//
BOOL CALLBACK OnConnect( PCONNECTION pConnection )
{
    InterlockedIncrement( &g_lOnConnectCount );

    // Allocate connection buffer.
    pConnection->pvPerConnectionUserData = malloc( BUF_SIZE );
    if( NULL == pConnection->pvPerConnectionUserData ){
        LogError( "malloc()", 0 );
        return FALSE;
        }

    /*
    // Get IP string.
    TCHAR szIP[20] = {0};
    wsprintf( szIP, T("%d.%d.%d.%d"), ( (PBYTE) &pConnection->dwIP )[0], 
                                      ( (PBYTE) &pConnection->dwIP )[1], 
                                      ( (PBYTE) &pConnection->dwIP )[2], 
                                      ( (PBYTE) &pConnection->dwIP )[3] );
    */

    // Receive request.
    DWORD dwRet = PServer.PostRecv( pConnection, 
                                    (PBYTE) pConnection->pvPerConnectionUserData, // Buffer.
                                    BUF_SIZE,                                     // Buffer size.
                                    NULL );
    if( dwRet != ERROR_SUCCESS ){
        LogError( "PostRecv()", dwRet );
        return FALSE;
        }

    return TRUE;
}

//##############################################################################################################//
VOID CALLBACK OnDisconnect( PCONNECTION pConnection )
{
    InterlockedIncrement( &g_lOnDisconnectCount );

    // Free memory.
    if( pConnection->pvPerConnectionUserData != NULL ){
        free( pConnection->pvPerConnectionUserData );
        }
}

//##############################################################################################################//
BOOL CALLBACK OnRecv( PCONNECTION pConnection, PIO_DATA pIoData )
{
    // Send request.
    DWORD dwRet = PServer.PostSend( pConnection,
                                    (PBYTE) pConnection->pvPerConnectionUserData, // Data.
                                    pIoData->dwBytesTransferred,                  // Data size.
                                    NULL );
    if( dwRet != ERROR_SUCCESS ){
        LogError( "PostSend()", dwRet );
        return FALSE;
        }

    return TRUE;
}

//##############################################################################################################//
BOOL CALLBACK OnSend( PCONNECTION pConnection, PIO_DATA pIoData )
{
    // Data transferred - close connection.
    return FALSE;
}

//##############################################################################################################//
VOID CALLBACK OnError( PCWSTR pszFunc, DWORD dwError )
{
    TCHAR szError[64] = {0};
    wsprintf( szError, T("%s(): %d"), pszFunc, dwError );
    SetDlgItemText( g_hwndMain, ID_STATIC_STATUS, szError );
}

//###############################################################################################################//
//###############################################################################################################//
//###############################################################################################################//
void DlgMain_OnCommand( HWND hWnd, int id, HWND hWndCtl, UINT codeNotify )
{
	switch( id ){
        case ID_BUTTON_START:{
            SetDlgItemText( hWnd, ID_STATIC_STATUS, T("Starting...") );
            EnableWindow( GetDlgItem( hWnd, ID_BUTTON_START ), FALSE );

            g_lOnConnectCount    = 0;
            g_lOnDisconnectCount = 0;

            PSERVERPARAM param = {0};

            /*
            // Available in full version.
            SYSTEM_INFO  sysinfo = {0};
            GetSystemInfo( &sysinfo );
            param.dwWorkerThreadsMin = sysinfo.dwNumberOfProcessors * 2;
            param.dwWorkerThreadsMax = sysinfo.dwNumberOfProcessors * 8;
            */

            param.dwWorkerThreadsIdleTimeout = 10000;
            param.dwCpuUsageMin              = 70;
            param.dwCpuUsageMax              = 90;
            param.dwMultipleIoReqsMax        = 1;
            param.dwPort                     = 6060;
            param.dwSocketRecvBufferSize     = -1;
            param.dwSocketSendBufferSize     = -1;
            param.dwConnectionsIdleTimeout   = 500;
            param.dwInitAccepts              = 500;
            param.CALLBACKS.OnConnect        = OnConnect;
            param.CALLBACKS.OnDisconnect     = OnDisconnect;
            param.CALLBACKS.OnRecv           = OnRecv;
            param.CALLBACKS.OnSend           = OnSend;
            param.CALLBACKS.OnError          = OnError;

            DWORD dwRet = PServer.Start( &param );
            if( dwRet != ERROR_SUCCESS ){
                TCHAR szError[64] = {0};
                wsprintf( szError, T("Start(): %d"), dwRet );
                SetDlgItemText( hWnd, ID_STATIC_STATUS, szError );
                EnableWindow( GetDlgItem( hWnd, ID_BUTTON_START ), TRUE );
                break;
                }

            SetTimer( hWnd, 1, 1000, NULL );

            SetDlgItemText( hWnd, ID_STATIC_STATUS, T("Started") );
            EnableWindow( GetDlgItem( hWnd, ID_BUTTON_STOP ), TRUE );

            g_fStarted = TRUE;
			break;
            }

        case ID_BUTTON_STOP:
            SetDlgItemText( hWnd, ID_STATIC_STATUS, T("Stopping...") );
            EnableWindow( GetDlgItem( hWnd, ID_BUTTON_STOP ), FALSE );

            PServer.Stop();

            KillTimer( hWnd, 1 );

            SetDlgItemText( hWnd, ID_STATIC_CPUUSAGE,     NULL );
            SetDlgItemText( hWnd, ID_STATIC_THREADS,      NULL );
            SetDlgItemText( hWnd, ID_STATIC_IOLEN,        NULL );
            SetDlgItemText( hWnd, ID_STATIC_CONNECTIONS,  NULL );
            SetDlgItemText( hWnd, ID_STATIC_ONCONNECT,    NULL );
            SetDlgItemText( hWnd, ID_STATIC_ONDISCONNECT, NULL );

            SetDlgItemText( hWnd, ID_STATIC_STATUS, T("Stopped") );
            EnableWindow( GetDlgItem( hWnd, ID_BUTTON_START ), TRUE );

            g_fStarted = FALSE;
			break;

        case ID_CHECK_ONTOP:
            SetWindowPos( hWnd, IsDlgButtonChecked( hWnd, ID_CHECK_ONTOP ) ? HWND_TOPMOST : HWND_NOTOPMOST,
                          0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE );
            break;
        }
}

//###############################################################################################################//
BOOL DlgMain_OnInitDialog( HWND hWnd, HWND hWndFocus, LPARAM lParam )
{
    g_hwndMain = hWnd;

    return TRUE;
}

//###############################################################################################################//
void DlgMain_OnTimer( HWND hWnd, UINT id )
{
    INFORMATION info = {0};

    PServer.QueryInformation( &info );

    SetDlgItemInt( hWnd, ID_STATIC_CPUUSAGE,     info.dwCpuUsage,           FALSE );
    SetDlgItemInt( hWnd, ID_STATIC_THREADS,      info.dwWorkerThreadsCount, FALSE );
    SetDlgItemInt( hWnd, ID_STATIC_IOLEN,        info.dwIoCompletionLen,    FALSE );
    SetDlgItemInt( hWnd, ID_STATIC_CONNECTIONS,  info.dwConnectionsCount,   FALSE );
    SetDlgItemInt( hWnd, ID_STATIC_ONCONNECT,    g_lOnConnectCount,         FALSE );
    SetDlgItemInt( hWnd, ID_STATIC_ONDISCONNECT, g_lOnDisconnectCount,      FALSE );
}

//###############################################################################################################//
void DlgMain_OnClose( HWND hWnd )
{
    if( g_fStarted ){
        SendMessage( hWnd, WM_COMMAND, ID_BUTTON_STOP, NULL );
        }

	EndDialog( hWnd, 0 );
}

//###############################################################################################################//
int WINAPI Dialog_Main( HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam )
{
    switch( message ){
        Dlg_Proc( hWnd, WM_INITDIALOG, DlgMain_OnInitDialog );
        Dlg_Proc( hWnd, WM_COMMAND,    DlgMain_OnCommand    );
        Dlg_Proc( hWnd, WM_TIMER,      DlgMain_OnTimer      );
        Dlg_Proc( hWnd, WM_CLOSE,      DlgMain_OnClose      );
        }

    return 0;
}

//##############################################################################################################//
int WINAPI _tWinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow )
{
    DialogBox( hInstance, MAKEINTRESOURCE( IDD_DIALOG_MAIN ), NULL, Dialog_Main );

    return 0;
}

//##############################################################################################################//