//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma comment( lib, "PServer" )

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#define PSERVERLIB extern "C" __declspec( dllimport )

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// Connection structure.
//
typedef struct _CONNECTION{
    SOCKET   Socket;                  // Client socket.
    DWORD    dwIP;                    // Client IP.
    PVOID    pvPerConnectionUserData; // Application-defined value given in callback functions.
}CONNECTION, *PCONNECTION;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// I/O completion structure.
//
typedef struct _IO_DATA{
    DWORD dwBytesTransferred; // Number of bytes transferred during an I/O operation that has completed.
    PVOID pvPerIoUserData;    // Application-defined value given in PServer_PostRecv or PServer_PostSend.
}IO_DATA, *PIO_DATA;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// 
// Callback functions.
//

//
// Called when a client connects.
//
// Parameters:
//     pConnection - [IN] Pointer to a CONNECTION structure.
//
// Return Values:
//     For the connection to be continued, the function must return TRUE. For the connection to be closed,
//     it must return FALSE.
//
// Remarks:
//
typedef BOOL (CALLBACK *ONCONNECTPROC)( PCONNECTION pConnection );

//
// Called when a client disconnects.
//
// Parameters:
//     pConnection - [IN] Pointer to a CONNECTION structure.
//
// Return Values:
//
// Remarks:
//
typedef VOID (CALLBACK *ONDISCONNECTPROC)( PCONNECTION pConnection );

//
// Called when a data receive request is completed.
//
// Parameters:
//     pConnection - [IN] Pointer to a CONNECTION structure.
//     pIoData     - [IN] Pointer to a IO_DATA structure.
//
// Return Values:
//     For the connection to be continued, the function must return TRUE. For the connection to be closed,
//     it must return FALSE.
//
// Remarks:
//
typedef BOOL (CALLBACK *ONRECVPROC)( PCONNECTION pConnection, PIO_DATA pIoData );

//
// Called when a data send request is completed.
//
// Parameters:
//     pConnection - [IN] Pointer to a CONNECTION structure.
//     pIoData     - [IN] Pointer to a IO_DATA structure.
//
// Return Values:
//     For the connection to be continued, the function must return TRUE. For the connection to be closed,
//     it must return FALSE.
//
// Remarks:
//
typedef BOOL (CALLBACK *ONSENDPROC)( PCONNECTION pConnection, PIO_DATA pIoData );

//
// Called when errors occur while the server is running.
//
// Parameters:
//     pszFunc - [IN] The name of the function that returned the error.
//     dwError - [IN] GetLastError/WSAGetLastError error code.
//
// Return Values:
//
// Remarks:
//
typedef VOID (CALLBACK *ONERRORPROC)( PCWSTR pszFunc, DWORD dwError );

//
// Callback function used with the PServer_EnumConnections function. It receives current connections.
//
// Parameters:
//     pConnection - [IN] Pointer to a CONNECTION structure.
//     pvParam     - [IN] Application-defined value given in PServer_EnumConnections.
//
// Return Values:
//     To continue enumeration, the callback function must return TRUE; to stop enumeration, it must return FALSE. 
//
// Remarks:
//
typedef BOOL (CALLBACK *ENUMCONNECTIONSPROC)( PCONNECTION pConnection, PVOID pvParam );

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// Server initialization structure.
//
typedef struct _PSERVERPARAM{
    // Minimum number of worker threads in the pool.
    DWORD dwWorkerThreadsMin;

    // Maximum number of worker threads in the pool.
    DWORD dwWorkerThreadsMax;

    // Idle timeout for worker threads after which they will be deleted if possible;
    // in milliseconds (0 - is not used).
    DWORD dwWorkerThreadsIdleTimeout;

    // Processor load till which new worker threads will be created if necessary; in percent.
    DWORD dwCpuUsageMin;

    // Processor load after which worker threads will be removed if possible; in percent.
    DWORD dwCpuUsageMax;

    // Maximum number of simultaneous I/O requests for each connection.
    DWORD dwMultipleIoReqsMax;

    // Port.
    DWORD dwPort;

    // Specifies the total per-socket buffer space reserved for receives (-1 - by default).
    DWORD dwSocketRecvBufferSize;

    // Specifies the total per-socket buffer space reserved for sends (-1 - by default).
    DWORD dwSocketSendBufferSize;

    // The frequency of sending packets for checking the connection availability;
    // in milliseconds (0 - KeepAlive is not used).
    DWORD dwKeepAliveTime;

    // Interval between sending activity messages when no response is received;
    // in milliseconds (0 - KeepAlive is not used).
    DWORD dwKeepAliveInterval;

    // Idle timeout for client sockets after which they will be closed;
    // in milliseconds (0 is not used).
    // Checked each time a new client connects.
    DWORD dwConnectionsIdleTimeout;

    // The number of client sockets created when the server is started.
    DWORD dwInitAccepts;

    struct _CALLBACKS{
        ONCONNECTPROC    OnConnect;
        ONDISCONNECTPROC OnDisconnect;
        ONSENDPROC       OnSend;
        ONRECVPROC       OnRecv;
        ONERRORPROC      OnError;
        }CALLBACKS;
}PSERVERPARAM, *PPSERVERPARAM;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// Information about the server status.
//
typedef struct _INFORMATION{
    DWORD dwCpuUsage;           // The current CPU usage.
    DWORD dwWorkerThreadsCount; // The current worker threads count.
    DWORD dwIoCompletionLen;    // The current number of unprocessed completed requests in the port queue.
    DWORD dwConnectionsCount;   // The current connections count.
}INFORMATION, *PINFORMATION;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// 
// Server functions.
//

//
// Start server.
//
// Parameters:
//     pParam - [IN] Pointer to a SERVERPARAM structure that contains the initialization parameters.
//
// Return Values:
//     ERROR_SUCCESS                - Success.
//     ERROR_INVALID_PARAMETER      - Invalid initialization parameter.
//     ERROR_ALREADY_EXISTS         - Server already started.
//     GetLastError/WSAGetLastError - All other errors.
//
// Remarks:
//
PSERVERLIB DWORD WINAPI PServer_Start( PPSERVERPARAM pParam );

//
// Stop server.
//
// Parameters:
//
// Return Values:
//
// Remarks:
//     Cannot be called from active threads (CALLBACK functions).
//
PSERVERLIB VOID WINAPI PServer_Stop();

//
// Data receive request.
//
// Parameters:
//     pConnection     - [IN] Pointer to a CONNECTION structure.
//     pbBuffer        - [IN] Buffer for the incoming data.
//     dwSize          - [IN] Length of pbBuffer.
//     pvPerIoUserData - [IN] Application-defined value.
//
// Return Values:
//     ERROR_SUCCESS                - Success.
//     ERROR_INVALID_PARAMETER      - Invalid parameter.
//     ERROR_TOO_MANY_OPEN_FILES    - The maximum number of simultaneous I/O requests for this
//                                    connection is exceeded.
//     GetLastError/WSAGetLastError - All other errors.
//
// Remarks:
//
PSERVERLIB DWORD WINAPI PServer_PostRecv( PCONNECTION pConnection,
                                          PBYTE       pbBuffer,
                                          DWORD       dwSize,
                                          PVOID       pvPerIoUserData );

//
// Data send request.
//
// Parameters:
//     pConnection     - [IN] Pointer to a CONNECTION structure.
//     pbBuffer        - [IN] Buffer containing the data to be transmitted.
//     dwSize          - [IN] Length of the data in pbBuffer.
//     pvPerIoUserData - [IN] Application-defined value.
//
// Return Values:
//     ERROR_SUCCESS                - Success.
//     ERROR_INVALID_PARAMETER      - Invalid parameter.
//     ERROR_TOO_MANY_OPEN_FILES    - The maximum number of simultaneous I/O requests for this
//                                    connection is exceeded.
//     GetLastError/WSAGetLastError - All other errors.
//
// Remarks:
//
PSERVERLIB DWORD WINAPI PServer_PostSend( PCONNECTION pConnection,
                                          PBYTE       pbBuffer,
                                          DWORD       dwSize,
                                          PVOID       pvPerIoUserData );

//
// Permit/forbid checking the idle time of connection.
//
// Parameters:
//     pConnection - [IN] Pointer to a CONNECTION structure.
//     fEnable     - [IN] TRUE - enabled, FALSE - disabled.
//
// Return Values:
//
// Remarks:
//     Checking is permitted by default.
//
PSERVERLIB VOID WINAPI PServer_EnableConnectionIdleCheck( PCONNECTION pConnection,
                                                          BOOL        fEnable );

//
// Close connection.
//
// Parameters:
//     pConnection - [IN] Pointer to a CONNECTION structure.
//
// Return Values:
//
// Remarks:
//
PSERVERLIB VOID WINAPI PServer_CloseConnection( PCONNECTION pConnection );

//
// Get information about the server status.
//
// Parameters:
//     pInformation - [OUT] Pointer to a INFORMATION structure that receives the information.
//
// Return Values:
//
// Remarks:
//
PSERVERLIB VOID WINAPI PServer_QueryInformation( PINFORMATION pInformation );

//
// Enumerate the current connections.
//
// Parameters:
//     pEnumConnectionsProc - [IN] Pointer to an application-defined callback function.
//     pvParam              - [IN] Specifies an application-defined value to be passed to the callback function.
//
// Return Values:
//
// Remarks:
//
PSERVERLIB VOID WINAPI PServer_EnumConnections( ENUMCONNECTIONSPROC pEnumConnectionsProc,
                                                PVOID               pvParam );

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////