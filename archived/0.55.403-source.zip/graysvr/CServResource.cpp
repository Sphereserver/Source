//
// CServResource.cpp
//

