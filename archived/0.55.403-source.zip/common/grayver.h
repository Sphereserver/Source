#define GRAY_VERSION	"4.0.3"		// share version with all files.
