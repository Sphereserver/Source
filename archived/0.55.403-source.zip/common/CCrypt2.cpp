// CCrypt2.cpp
//

