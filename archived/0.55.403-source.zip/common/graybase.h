//
// graybase.h
// Copyright Menace Software (www.menasoft.com).
// common header file.
//


