#include "SphereTask.h"
#include "ElementIdMap.h"

//
// SphereTask
//
TaskHolder::TaskHolder(void)
{
}

TaskHolder::~TaskHolder(void)
{
	clear();
}

void TaskHolder::add(SphereTask* task)
{
	m_tasks.push_back(task);
}

void TaskHolder::clear(void)
{
	for (TaskContainer::iterator it = m_tasks.begin(); it != m_tasks.end(); it = m_tasks.erase(it))
		delete *it;

	for (DataContainer::iterator it = m_data.begin(); it != m_data.end(); it++)
	{
		if (it->second != NULL)
		{
			delete it->second;
			it->second = NULL;
		}
	}

	m_data.clear();
}

void TaskHolder::execute(void)
{
	for (TaskContainer::iterator it = m_tasks.begin(); it != m_tasks.end(); it++)
	{
		SphereTask* task = *it;
		if (task == NULL)
			continue;

		if (task->execute())
			continue;

		cout << _T("Process has been aborted.") << std::endl;
		break;
	}
}

void* TaskHolder::getData(string key) const
{
	DataContainer::const_iterator it = m_data.find(key);
	if (it == m_data.end())
		return NULL;

	return it->second;
}

void TaskHolder::setData(string key, void* data)
{
	DataContainer::iterator it = m_data.find(key);
	if (it == m_data.end())
		m_data[key] = data;
	else
	{
		if (it->second != NULL)
		{
			cout << _T("WARNING: Data being overwritten in global data store.") << std::endl;
			delete it->second;
		}

		it->second = data;
	}
}

void TaskHolder::loadPaths(void)
{
	// try to locate sphere.ini
	string iniPath(_T(""));
	if (FileSystem::Exists(_T("Sphere.ini")))
		iniPath = _T("Sphere.ini");
#ifndef _WIN32
	else if (FileSystem::Exists(_T("sphere.ini")))
		iniPath = _T("sphere.ini");
#endif

	if (iniPath.empty() == false)
	{
		// load scripts and save path from ini
		ScriptFile ini(iniPath);
		ScriptElement* element = ini.read(_T("SPHERE"));
		if (element != NULL)
		{
			m_scriptPath = element->getProperty(_T("SCPFILES"));
			m_savePath = element->getProperty(_T("WORLDSAVE"));
		}

		ini.close();
	}

	// fall back to default values
	if (m_scriptPath.empty())
	{
		m_scriptPath = string(_T("./scripts"));
		cout << _T("Failed to detect scripts path, defaulting to: ") << m_scriptPath << std::endl;
	}
	else
		cout << _T("Scripts Path: ") << m_scriptPath << std::endl;

	if (m_savePath.empty())
	{
		m_savePath = string(_T("./save"));
		cout << _T("Failed to detect save path, defaulting to: ") << m_savePath << std::endl;
	}
	else
		cout << _T("Save Path: ") << m_savePath << std::endl;
}

string& TaskHolder::getScriptPath(void)
{
	if (m_scriptPath.empty())
		loadPaths();
	return m_scriptPath;
}

string& TaskHolder::getSavePath(void)
{
	if (m_savePath.empty())
		loadPaths();
	return m_savePath;
}

//
// SphereTask
//
SphereTask::SphereTask(TaskHolder* parent) : m_parent(parent)
{
}

SphereTask::~SphereTask(void)
{
}

bool SphereTask::execute(void)
{
	try
	{
		return onExecute();
	}
	catch (...)
	{
		DWORD error = GetLastError();
		_tprintf(_T("Error code 0x%08X raised.\n"), error);
		return false;
	}
}

void SphereTask::getScriptFiles(FileList& scripts)
{
	scripts.clear();
	FileSystem::FindFiles(m_parent->getScriptPath(), string(_T("*.scp")), true, scripts);
}

void SphereTask::getSaveFiles(FileList& saves)
{
	saves.clear();
	FileSystem::FindFiles(m_parent->getSavePath().c_str(), string(_T("*.scp")), true, saves);
}

bool SphereTask::IsNumeric(string& value)
{
	if (value.empty())
		return false;

	bool isHex = (value.at(0) == _T('0'));

	for (string::iterator it = value.begin(); it != value.end(); it++)
	{
		if (*it >= _T('0') && *it <= _T('9'))
			continue;
		else if (isHex && tolower(*it) >= _T('a') && tolower(*it) <= _T('f'))
			continue;

		return false;
	}

	return true;
}

bool SphereTask::IsNumeric(LPCTSTR value)
{
	if (value == NULL || value[0] == _T('\0'))
		return false;

	bool isHex = (value[0] == _T('0'));
	for (int i = 0; value[i] != _T('\0'); i++)
	{
		TCHAR c = value[i];
		if (c >= _T('0') && c <= _T('9'))
			continue;
		else if (isHex && tolower(c) >= _T('a') && tolower(c) <= _T('f'))
			continue;

		return false;
	}

	return true;
}

int SphereTask::ParseNumber(string& value)
{
	if (value.empty())
		return 0;

	stringstream ss;
	if (value.at(0) == _T('0'))
		ss << std::hex;
	ss << value.c_str();

	int result;
	ss >> result;
	return result;
}

int SphereTask::ParseNumber(LPCTSTR value)
{
	if (value == NULL || value[0] == _T('\0'))
		return 0;

	stringstream ss;
	if (value[0] == _T('0'))
		ss << std::hex;
	ss << value;

	int result;
	ss >> result;
	return result;
}

string SphereTask::FormatNumber(int value)
{
	TCHAR buffer[64];
	_stprintf(buffer, _T("0%x"), value);
	return string(buffer);
}

string SphereTask::generateDefname(ScriptElement* element)
{
	if (element == NULL)
		return _T("");

	// check if the id is already the defname
	if (IsNumeric(element->getId()) == false)
		return element->getId();

	// check for DEFNAME property
	string defname = element->getProperty(_T("DEFNAME"));
	if (defname.empty() == false)
		return defname;

	// generate defname from name or description
	string name = element->getProperty(_T("NAME"));
	if (name.empty())
		name = element->getProperty(_T("DESCRIPTION"));

	if (name.empty() == false)
	{
		ostringstream defnameBuilder;
		defnameBuilder << _T("i_");
		bool underscore = true;
		for (string::iterator it = name.begin(); it != name.end(); it++)
		{
			TCHAR c = *it;
			if (isalpha(c) || isdigit(c))
			{
				defnameBuilder << c;
				underscore = false;
			}
			else if (underscore == false)
			{
				defnameBuilder << _T('_');
				underscore = true;
			}

		}

		defname = defnameBuilder.str();
	    string defnameAdjusted = defname;

		// append _x to make the defname unique
		for (int i = 2; defnameExists(defnameAdjusted.c_str()) && i < 50000; i++)
		{
			defnameBuilder.str(_T(""));
			defnameBuilder << defname << _T("_") << i;
			defnameAdjusted = defnameBuilder.str();
		}

		cout << _T("WARNING: Generated defname '") << defnameAdjusted.c_str() << _T("' for ") << element->getType() << _T(" ") << element->getId() << std::endl;
		return defnameAdjusted;
	}

	// nothing suitable, so just make sure the numeric id is in a valid range
	int elementId = ParseNumber(element->getId());
	if (IsStygianAbyssId(elementId) == false)
		return element->getId();

	string adjustedId = FormatNumber(elementId + 0x4000);
	cout << _T("WARNING: Generated new id'") << adjustedId.c_str() << _T("' for ") << element->getType() << _T(" ") << element->getId() << std::endl;
	return adjustedId;
}

void SphereTask::recordNewId(ScriptElement* element)
{
	if (element == NULL || element->isIdModified() == false)
		return;

	ElementIdMap* map = static_cast<ElementIdMap*>(m_parent->getData(_T("ElementIdMap")));
	if (map == NULL)
	{
		map = new ElementIdMap();
		m_parent->setData(_T("ElementIdMap"), map);
	}

	// try to use the defname as the id if it's available
	string updatedId = element->getProperty(_T("DEFNAME"));
	if (updatedId.empty())
		updatedId = element->getId();

	map->add(element->getOriginalId(), updatedId);
}

string SphereTask::retrieveNewId(string originalId)
{
	ElementIdMap* map = static_cast<ElementIdMap*>(m_parent->getData(_T("ElementIdMap")));
	if (map == NULL)
		return originalId;

	return map->translateId(originalId);
}

void SphereTask::recordDefname(LPCTSTR defname)
{
	if (defname == NULL || defname[0] == _T('\0'))
		return;

	DefnameList* defnames = static_cast<DefnameList*>(m_parent->getData(_T("DefnameList")));
	if (defnames == NULL)
	{
		defnames = new DefnameList();
		m_parent->setData(_T("DefnameList"), defnames);
	}

	defnames->push_back(string(defname));
}

bool SphereTask::defnameExists(string& defname)
{
	if (defname.empty())
		return false;

	return defnameExists(defname.c_str());
}

bool SphereTask::defnameExists(LPCTSTR defname)
{
	if (defname == NULL || defname[0] == _T('\0'))
		return false;

	DefnameList* defnames = static_cast<DefnameList*>(m_parent->getData(_T("DefnameList")));
	if (defnames == NULL)
		return false;

	for (DefnameList::iterator it = defnames->begin(); it != defnames->end(); it++)
	{
		if (_tcsicmp(it->c_str(), defname) == 0)
			return true;
	}

	return false;
}


//
// PreCheckTask
//
PreCheckTask::PreCheckTask(TaskHolder* parent) : SphereTask(parent)
{
}

bool PreCheckTask::onExecute(void)
{
	bool ret = true;
	cout << _T("Executing pre-update checks...") << std::endl;

	FileList files;

	// check for existing script backups
	getScriptFiles(files);
	if (files.empty())
	{
		cout << _T("ERROR: No script files to process.") << std::endl;
		ret = false;
	}
	else for (FileList::iterator it = files.begin(); it != files.end(); it++)
	{
		if (FileSystem::BackupExists((*it)))
		{
			cout << _T("ERROR: Backup exists for script file: ") << (*it).c_str() << std::endl;
			ret = false;
		}
	}

	// load defnames from scripts
	for (FileList::iterator it = files.begin(); it != files.end(); it++)
	{
		ScriptFile script(*it);
		loadDefinitions(script);
	}

	// check for existing save backups
	getSaveFiles(files);
	if (files.empty())
	{
		cout << _T("WARNING: No save files to process. (world saves will not be updated)") << std::endl;
	}
	else for (FileList::iterator it = files.begin(); it != files.end(); it++)
	{
		if (FileSystem::BackupExists((*it)))
		{
			cout << _T("ERROR: Backup exists for save file: ") << (*it).c_str() << std::endl;
			ret = false;
		}
	}

	return ret;
}

void PreCheckTask::loadDefinitions(ScriptFile& script)
{
	ScriptElement* element(NULL);
	while ((element = script.read(NULL)) != NULL)
	{
		if (element->getId()[0] == _T('\0'))
			continue;

		if (IsNumeric(element->getId()) == false)
			recordDefname(element->getId());

		string defname = element->getProperty(_T("DEFNAME"));
		if (defname.empty() == false)
			recordDefname(defname.c_str());
	}

	script.close();
}

//
// UpdateMultisTask
//
UpdateMultisTask::UpdateMultisTask(TaskHolder* parent) : SphereTask(parent)
{
}

bool UpdateMultisTask::onExecute(void)
{
	bool ret = true;
	cout << _T("Updating multi definitions...") << std::endl;

	FileList files;
	getScriptFiles(files);
	for (FileList::iterator it = files.begin(); it != files.end(); it++)
	{
		ScriptFile script(*it);
		processScript(script);
	}

	return ret;
}

void UpdateMultisTask::processScript(ScriptFile& script)
{
	ScriptElement* element(NULL);
	ScriptElementList affectedElements;

	while ((element = script.read(_T("ITEMDEF"))) != NULL)
	{
		if (IsNumeric(element->getId()) == false)
			continue;

		string type = element->getProperty(_T("TYPE"));
		if (isTypeMulti(type) == false)
			continue;

		int id = ParseNumber(element->getId());
		if (IsStygianAbyssId(id) == false)
			continue;

		element->setType(string(_T("MULTIDEF")));
		element->setId(FormatNumber(id - 0x4000));

		affectedElements.push_back(element);
		recordNewId(element);
	}

	script.close();
	script.save(affectedElements);
}

bool UpdateMultisTask::isTypeMulti(string type)
{
	if (_tcsicmp(type.c_str(), _T("t_multi")) == 0)
		return true;
	if (_tcsicmp(type.c_str(), _T("t_multi_custom")) == 0)
		return true;
	if (_tcsicmp(type.c_str(), _T("t_ship")) == 0)
		return true;
	return false;
}

//
// UpdateBaseItemsTask
//
UpdateBaseItemsTask::UpdateBaseItemsTask(TaskHolder* parent) : SphereTask(parent)
{
}

bool UpdateBaseItemsTask::onExecute(void)
{
	bool ret = true;
	cout << _T("Updating item definitions...") << std::endl;

	FileList files;
	getScriptFiles(files);
	for (FileList::iterator it = files.begin(); it != files.end(); it++)
	{
		ScriptFile script(*it);
		processScript(script);
	}

	return ret;
}

void UpdateBaseItemsTask::processScript(ScriptFile& script)
{
	ScriptElement* element(NULL);
	ScriptElementList affectedElements;

	while ((element = script.read(_T("ITEMDEF"))) != NULL)
	{
		if (IsNumeric(element->getId()) == false)
			continue;
		else if (element->getProperty(_T("ID")).empty())
			continue;

		int id = ParseNumber(element->getId());
		if (IsStygianAbyssId(id) == false)
			continue;

		element->setId(generateDefname(element));
		element->setProperty(string(_T("DEFNAME")), string(_T("")), true);

		affectedElements.push_back(element);
		recordNewId(element);
	}

	script.close();
	script.save(affectedElements);
}

//
// UpdateBaseItemsTask
//
UpdateInheritedItemsTask::UpdateInheritedItemsTask(TaskHolder* parent) : SphereTask(parent)
{
}

bool UpdateInheritedItemsTask::onExecute(void)
{
	bool ret = true;
	cout << _T("Updating inherited item definitions...") << std::endl;

	FileList files;
	getScriptFiles(files);
	for (FileList::iterator it = files.begin(); it != files.end(); it++)
	{
		ScriptFile script(*it);
		processScript(script);
	}

	return ret;
}

void UpdateInheritedItemsTask::processScript(ScriptFile& script)
{
	ScriptElement* element(NULL);
	ScriptElementList affectedElements;

	while ((element = script.read(_T("ITEMDEF"))) != NULL)
	{
		string baseElement = element->getProperty(_T("ID"));
		if (IsNumeric(baseElement) == false)
			continue;

		int baseElementId = ParseNumber(baseElement);
		if (IsStygianAbyssId(baseElementId) == false)
			continue;

		string updatedId = retrieveNewId(baseElement);
		if (updatedId.empty() == false && _tcsicmp(updatedId.c_str(), baseElement.c_str()) != 0)
		{
			element->setProperty(string(_T("ID")), updatedId, true);
			affectedElements.push_back(element);
		}
	}

	script.close();
	script.save(affectedElements);
}

//
// UpdateSavedItemsTask
//
UpdateSavedItemsTask::UpdateSavedItemsTask(TaskHolder* parent) : SphereTask(parent)
{
}

bool UpdateSavedItemsTask::onExecute(void)
{
	bool ret = true;
	cout << _T("Updating world saves...") << std::endl;

	FileList files;
	getSaveFiles(files);
	for (FileList::iterator it = files.begin(); it != files.end(); it++)
	{
		ScriptFile script(*it);
		processSave(script);
	}

	return ret;
}

void UpdateSavedItemsTask::processSave(ScriptFile& script)
{
	ScriptElement* element(NULL);
	ScriptElementList affectedElements;

	while ((element = script.read(NULL)) != NULL)
	{
		if (_tcsicmp(element->getType(), _T("WORLDITEM")) != 0 && _tcsicmp(element->getType(), _T("WI")) != 0)
			continue;
		if (IsNumeric(element->getId()) == false)
			continue;

		int baseElementId = ParseNumber(element->getId());
		if (IsStygianAbyssId(baseElementId) == false)
			continue;

		string updatedId = retrieveNewId(element->getId());
		if (updatedId.empty() == false && _tcsicmp(updatedId.c_str(), element->getId()) != 0)
		{
			element->setId(updatedId);
			affectedElements.push_back(element);
		}
	}

	script.close();
	script.save(affectedElements);
}
