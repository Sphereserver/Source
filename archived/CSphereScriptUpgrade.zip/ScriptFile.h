#ifndef __ScriptFile_H__
#define __ScriptFile_H__
#pragma once
#include "common.h"

//
// ScriptProperty
//
class ScriptProperty
{
private:
	string m_key;
	string m_value;

public:
	ScriptProperty(string key, string value);

	string getKey(void) { return m_key; }
	string getValue(void) { return m_value; }
	void setValue(string value) { m_value = value; }
};
typedef std::vector<ScriptProperty> PropertyList;

//
// ScriptElement
//
class ScriptElement
{
private:
	string m_type;
	string m_id;

	string m_originalType;
	string m_originalId;

	PropertyList m_properties;

	bool m_isModified;
	bool m_isTypeModified;
	bool m_isIdModified;

public:
	ScriptElement(string type, string id);

public:
	LPCTSTR getType(void) const { return m_type.c_str(); }
	LPCTSTR getId(void) const { return m_id.c_str(); }
	LPCTSTR getOriginalType(void) const { return m_originalType.c_str(); }
	LPCTSTR getOriginalId(void) const { return m_originalId.c_str(); }

	bool isModified(void) const { return m_isModified || m_isTypeModified || m_isIdModified; }
	bool isTypeModified(void) const { return m_isTypeModified; }
	bool isIdModified(void) const { return m_isIdModified; }

	void setModified(bool value) { m_isModified = value; }
	void setTypeModified(bool value) { m_isTypeModified = value; }
	void setIdModified(bool value) { m_isIdModified = value; }

	void setType(string value) { m_type = value; setTypeModified(true); }
	void setId(string value) { m_id = value; setIdModified(true); }

	bool isOriginalElement(string& type, string& id) const { return _tcsicmp(m_originalType.c_str(), type.c_str()) == 0 && _tcsicmp(m_originalId.c_str(), id.c_str()) == 0; }

	string getProperty(string& key);
	string getProperty(LPCTSTR key);
	void setProperty(string key, string value, bool singular = false);
	void removeProperty(string& key);
	void removeProperty(LPCTSTR key);

	PropertyList& getProperties(void) { return m_properties; };

private:
	PropertyList::iterator findProperty(string& key);
	PropertyList::iterator findProperty(LPCTSTR key);
};
typedef std::vector<ScriptElement*> ScriptElementList;

//
// ScriptFile
//
class ScriptFile
{
private:
	string m_path;
	ifstream m_stream;
	string m_cachedLine;
	ScriptElementList m_elements;

public:
	ScriptFile(string& path);
	~ScriptFile(void);

	ScriptElement* read(string& desiredType);
	ScriptElement* read(LPCTSTR desiredType);
	void close(void);
	void save(ScriptElementList& elements);

private:
	bool readLine(string& line);
	void processLine(string& line);
	void parseElementType(string& line, string& type, string& id);
	bool parseProperty(string& line, string& key, string& value);
};

#endif
