#ifndef __ElementIdMap_H__
#define __ElementIdMap_H__
#pragma once
#include "common.h"

class ElementIdMap
{
private:
	struct Entry
	{
		string original;
		string updated;

		Entry(string original, string updated) : original(original), updated(updated) { };
	};

	typedef std::vector<Entry*> EntryMap;

	EntryMap m_entries;

public:
	ElementIdMap(void);
	~ElementIdMap(void);

	void add(string key, string value);
	string translateId(string& id);

private:
	Entry* findEntry(string& id);
};

#endif
