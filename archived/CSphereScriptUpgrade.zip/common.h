// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#ifndef __common_h__
#define __common_h__
#pragma once

#ifdef _WIN32
// The following macros define the minimum required platform.  The minimum required platform
// is the earliest version of Windows, Internet Explorer etc. that has the necessary features to run 
// your application.  The macros work by enabling all features available on platform versions up to and 
// including the version specified.

// Modify the following defines if you have to target a platform prior to the ones specified below.
// Refer to MSDN for the latest info on corresponding values for different platforms.
#	ifndef _WIN32_WINNT            // Specifies that the minimum required platform is Windows Vista.
#		define _WIN32_WINNT 0x0600     // Change this to the appropriate value to target other versions of Windows.
#	endif
#endif

#include <stdio.h>
#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include <sys/stat.h>
#include <limits>
#include <sstream>
#include <map>
#ifdef _WIN32
#	include <tchar.h>
#	include <windows.h>
#else
#	include <errno.h>
#	include <dirent.h>
#endif

#ifdef UNICODE
	typedef std::wstring string;
	typedef std::wifstream ifstream;
	typedef std::wofstream ofstream;
	typedef std::wstringstream stringstream;
	typedef std::wostringstream ostringstream;
#	define cout std::wcout
#	define cin std::wcin
#	ifndef _WIN32
#		define TCHAR		wchar_t
#		define LPCTSTR		const TCHAR*
#		define _tcsicmp		wcsicmp
#		define _tcsnicmp	wcsnicmp
#		define _tcslen		wcslen
#		define _T(x)		L ## x
#		define _tunlink		wunlink
#		define _trename		wrename
#		define _stprintf	wsprintf
#		define _tprintf		wprintf
#	endif
#else
	typedef std::string string;
	typedef std::ifstream ifstream;
	typedef std::ofstream ofstream;
	typedef std::stringstream stringstream;
	typedef std::ostringstream ostringstream;
#	define cout std::cout
#	define cin std::cin
#	ifndef _WIN32
#		define TCHAR		char
#		define LPCTSTR		const TCHAR*
#		define _tcsicmp		strcasecmp
#		define _tcsnicmp	strncasecmp
#		define _tcslen		strlen
#		define _T(x)		x
#		define _tunlink		unlink
#		define _trename		rename
#		define _stprintf	sprintf
#		define _tprintf		printf
#	endif
#endif

#ifdef WIN32
#	pragma warning(disable:4996) // disable secure warnings
#else
#	define DWORD unsigned long
#	define GetLastError() errno
#endif

#define countof(a) (sizeof(a) / sizeof(a[0]))

#endif
