#include "ScriptFile.h"
#include "FileSystem.h"

//
// ScriptProperty
//
ScriptProperty::ScriptProperty(string key, string value) : m_key(key), m_value(value)
{
}

//
// ScriptElement
//
ScriptElement::ScriptElement(string type, string id) : m_type(type), m_id(id), m_originalType(type), m_originalId(id), m_isModified(false), m_isTypeModified(false), m_isIdModified(false)
{
}

string ScriptElement::getProperty(string& key)
{
	return getProperty(key.c_str());
}

string ScriptElement::getProperty(LPCTSTR key)
{
	PropertyList::iterator it = findProperty(key);
	if (it != m_properties.end())
		return it->getValue();

	return string(_T(""));
}

void ScriptElement::setProperty(string key, string value, bool singular)
{
	PropertyList::iterator it = singular? findProperty(key) : m_properties.end();
	if (it != m_properties.end())
		it->setValue(value);
	else
		m_properties.push_back(ScriptProperty(key, value));

	setModified(true);
}

void ScriptElement::removeProperty(string& key)
{
	removeProperty(key.c_str());
}

void ScriptElement::removeProperty(LPCTSTR key)
{
	PropertyList::iterator it = findProperty(key);
	if (it != m_properties.end())
		m_properties.erase(it);
}

PropertyList::iterator ScriptElement::findProperty(string& key)
{
	return findProperty(key.c_str());
}

PropertyList::iterator ScriptElement::findProperty(LPCTSTR key)
{
	for (PropertyList::iterator it = m_properties.begin(); it != m_properties.end(); it++)
	{
		if (_tcsicmp(key, it->getKey().c_str()) == 0)
			return it;
	}

	return m_properties.end();
}

//
// ScriptFile
//
ScriptFile::ScriptFile(string& path) : m_path(path), m_stream(path.c_str())
{
}

ScriptFile::~ScriptFile(void)
{
	for (ScriptElementList::iterator it = m_elements.begin(); it != m_elements.end(); it = m_elements.erase(it))
		delete *it;
}

ScriptElement* ScriptFile::read(string& desiredType)
{
	return read(desiredType.c_str());
}

ScriptElement* ScriptFile::read(LPCTSTR desiredType)
{
	ScriptElement* result = NULL;
	string line;
	while (readLine(line))
	{
		if (line.empty())
			continue;

		if (line[0] == _T('['))
		{
			if (result != NULL)
			{
				m_cachedLine = line;
				break;
			}
			
			string type, id;
			parseElementType(line, type, id);

			if (desiredType == NULL || desiredType[0] == _T('\0') || _tcsicmp(type.c_str(), desiredType) == 0)
			{
				result = new ScriptElement(type, id);
				m_elements.push_back(result);
			}
		}
		else if (_tcsnicmp(line.c_str(), _T("ON="), 3) == 0 || _tcsnicmp(line.c_str(), _T("ONTRIGGER="), 3) == 0)
		{
			if (result != NULL)
				break;
		}
		else if (result != NULL)
		{
			string key, value;
			if (parseProperty(line, key, value))
				result->setProperty(key, value);
		}
	}

	if (result != NULL)
		result->setModified(false);


	return result;
}

bool ScriptFile::readLine(string& line)
{
	if (m_cachedLine.empty() == false)
	{
		line = m_cachedLine;
		m_cachedLine.clear();
		return true;
	}
	else if (m_stream.eof() || m_stream.good() == false)
		return false;
	else if (std::getline(m_stream, line) == false)
		return false;

	processLine(line);
	return true;
}

void ScriptFile::close(void)
{
	if (m_stream.is_open())
		m_stream.close();
}

void ScriptFile::save(ScriptElementList& elements)
{
	if (elements.empty())
		return;

	// check if any elements are actually modified
	bool changesMade = false;
	for (ScriptElementList::iterator it = elements.begin(); it != elements.end() && changesMade == false; it++)
		changesMade = (*it)->isModified();

	if (changesMade == false)
		return;

	if (FileSystem::CreateBackup(m_path) == false)
	{
		cout << _T("Failed to backup file '") << m_path << _T("', changes will not be saved.") << std::endl;
		return;
	}

	string backupPath = FileSystem::CreateBackupName(m_path);

	ifstream original(backupPath.c_str());
	ofstream output(m_path.c_str());

	ScriptElement* element = NULL;
	string originalLine;
	while (original.eof() == false && original.good() && std::getline(original, originalLine))
	{
		string trimmedLine = originalLine;
		processLine(trimmedLine);

		if (trimmedLine.empty() == false)
		{
			if (trimmedLine[0] == _T('['))
			{
				if (element != NULL)
				{
					// output remaining properties
					for (PropertyList::iterator it = element->getProperties().begin(); it != element->getProperties().end(); it++)
					{
						if (_tcslen(it->getValue().c_str()) > 0)
							output << it->getKey() << _T("=") << it->getValue() << std::endl;
					}

					element = NULL;
				}
				
				string type, id;
				parseElementType(trimmedLine, type, id);

				// find matching element in list
				for (ScriptElementList::iterator it = elements.begin(); it != elements.end() && element == NULL; it++)
				{
					if ((*it)->isOriginalElement(type, id))
						element = *it;
				}

				// check if element has been changed
				if (element != NULL && element->isModified() == false)
					element = NULL;

				// check if declaration needs to be changed
				if (element != NULL && (element->isIdModified() || element->isTypeModified()))
				{
					if (_tcslen(element->getId()) <= 0)
						output << _T("[") << element->getType() << _T("]") << std::endl;
					else
						output << _T("[") << element->getType() << _T(" ") << element->getId() << _T("]") << std::endl;

					continue;
				}
			}
			else if (_tcsnicmp(trimmedLine.c_str(), _T("ON="), 3) == 0 || _tcsnicmp(trimmedLine.c_str(), _T("ONTRIGGER="), 3) == 0)
			{
				if (element != NULL)
				{
					// output remaining properties
					for (PropertyList::iterator it = element->getProperties().begin(); it != element->getProperties().end(); it++)
					{
						if (_tcslen(it->getValue().c_str()) > 0)
							output << it->getKey() << _T("=") << it->getValue() << std::endl;
					}

					element = NULL;
				}
			}
			else if (element != NULL)
			{
				string key, value;
				if (parseProperty(trimmedLine, key, value))
				{
					string newValue = element->getProperty(key);
					element->removeProperty(key);

					if (_tcsicmp(value.c_str(), newValue.c_str()) != 0)
					{
						if (_tcslen(newValue.c_str()) > 0)
							output << key << _T("=") << newValue << std::endl;
						continue;
					}
				}
			}
		}

		output << originalLine << std::endl;
	}

	original.close();
	output.close();

	cout << _T("File '") << m_path << _T("' has been updated.") << std::endl;
}

void ScriptFile::processLine(string& line)
{
	string::size_type pos(string::npos);
	
	// remove comments
	pos = line.find_first_of(_T("//"), 0);
	if (pos != line.npos)
		line.erase(pos);

	// remove leading whitespace
	pos = line.find_first_not_of(_T(" \t\r\n"));
	if (pos != line.npos && pos > 0)
		line.erase(0, pos);

	// remove trailing whitespace
	pos = line.find_last_not_of(_T(" \t\r\n"));
	if (pos != line.npos && (pos + 1) < line.length())
		line.erase(pos+1);
}

void ScriptFile::parseElementType(string &line, string &type, string &id)
{
	type.clear();
	id.clear();

	string::size_type pos_from(string::npos);
	string::size_type pos_to(string::npos);

	// find start of descriptor
	pos_from = line.find_first_of(_T('['));
	if (pos_from == line.npos)
		pos_from = 0;
	else
		pos_from++;

	pos_to = line.find_first_of(_T(" \t\r\n]"), pos_from);
	if (pos_to == line.npos)
		pos_to = line.length() - 1;

	type = line.substr(pos_from, pos_to - pos_from);

	// find start of id
	pos_from = pos_to + 1;
	pos_to = line.find_first_of(_T(" \t\r\n]"), pos_from);
	if (pos_to == line.npos)
		pos_to = line.length() - 1;

	id = line.substr(pos_from, pos_to - pos_from);

	processLine(type);
	processLine(id);
}

bool ScriptFile::parseProperty(string &line, string &key, string &value)
{
	string::size_type pos = line.find_first_of(_T('='));
	if (pos == line.npos)
	{
		key.clear(); value.clear();
		return false;
	}

	key = line.substr(0, pos);
	value = line.substr(pos + 1);

	processLine(key);
	processLine(value);
	return true;
}
