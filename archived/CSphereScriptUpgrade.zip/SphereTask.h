#ifndef __SphereTask_H__
#define __SphereTask_H__
#pragma once

#include "common.h"
#include "FileSystem.h"
#include "ScriptFile.h"

class SphereTask;
typedef std::vector<SphereTask*> TaskContainer;

// holder for tasks
class TaskHolder
{
private:
	string m_scriptPath;
	string m_savePath;
	TaskContainer m_tasks;

	typedef std::map<string, void*> DataContainer;
	DataContainer m_data;

public:
	TaskHolder(void);
	~TaskHolder(void);

	void add(SphereTask* task);				// add task
	void clear(void);						// clear tasks
	void execute(void);						// execute contained tasks

	void* getData(string key) const;		// get value of custom data field
	void setData(string key, void* data);	// set value of custom data field

	void loadPaths(void);					// load script & save paths
	string& getScriptPath(void);			// get script path
	string& getSavePath(void);				// get save path
};

// base class for tasks
class SphereTask
{
protected:
	TaskHolder* m_parent;
	typedef std::vector<string> DefnameList;

public:
	SphereTask(TaskHolder* parent);
	virtual ~SphereTask(void);

	bool execute();								// execute task

protected:
	virtual bool onExecute(void) = 0;						// abstract task execute() method
	void getScriptFiles(FileList& scripts);					// populate scripts with list of script files
	void getSaveFiles(FileList& saves);						// populate saves with list of worldsave files
	void recordNewId(ScriptElement* element);				// record mapping between old and new id
	string retrieveNewId(string originalId);				// retrieve mapping for an old id
	void recordDefname(LPCTSTR defname);					// record a defname
	bool defnameExists(string& defname);					// check if a defname exists
	bool defnameExists(LPCTSTR defname);					// check if a defname exists
	string generateDefname(ScriptElement* element);			// generate defname for element

public:
	static bool IsNumeric(string& value);					// check if value is numeric
	static bool IsNumeric(LPCTSTR value);					// check if value is numeric
	static int ParseNumber(string& value);					// convert value to number
	static int ParseNumber(LPCTSTR value);					// convert value to number
	static string FormatNumber(int value);					// format number as string
	static bool IsStygianAbyssId(int id) { return id >= 0x4000 && id <= 0x7FFF; }	// determine if id is in the UO:SA range
};

// pre-update task
class PreCheckTask : public SphereTask
{
public:
	PreCheckTask(TaskHolder* parent);

protected:
	bool onExecute(void);
	void loadDefinitions(ScriptFile& script);
};

// update multi definitions to use MULTIDEF
class UpdateMultisTask : public SphereTask
{
public:
	UpdateMultisTask(TaskHolder* parent);

protected:
	bool onExecute(void);

private:
	void processScript(ScriptFile& script);
	bool isTypeMulti(string type);
};

// update item definitions
class UpdateBaseItemsTask : public SphereTask
{
public:
	UpdateBaseItemsTask(TaskHolder* parent);

protected:
	bool onExecute(void);

private:
	void processScript(ScriptFile& script);
};

// update inherited item definitions
class UpdateInheritedItemsTask : public SphereTask
{
public:
	UpdateInheritedItemsTask(TaskHolder* parent);

protected:
	bool onExecute(void);

private:
	void processScript(ScriptFile& script);
};

// update items in world save
class UpdateSavedItemsTask : public SphereTask
{
public:
	UpdateSavedItemsTask(TaskHolder* parent);

protected:
	bool onExecute(void);

private:
	void processSave(ScriptFile& script);
};

#endif
