#include "ElementIdMap.h"
#include "SphereTask.h"

ElementIdMap::ElementIdMap(void)
{
}

ElementIdMap::~ElementIdMap(void)
{
	for (EntryMap::iterator it = m_entries.begin(); it != m_entries.end(); it = m_entries.erase(it))
		delete *it;
}

void ElementIdMap::add(string original, string updated)
{
	m_entries.push_back(new Entry(original, updated));
}

string ElementIdMap::translateId(string& id)
{
	Entry* entry = findEntry(id);
	if (entry == NULL)
		return id;

	return entry->updated;
}

ElementIdMap::Entry* ElementIdMap::findEntry(string& id)
{
	bool isNumeric = SphereTask::IsNumeric(id);
	int numericId = isNumeric? SphereTask::ParseNumber(id) : INT_MIN;

	for (EntryMap::iterator it = m_entries.begin(); it != m_entries.end(); it++)
	{
		if (_tcsicmp((*it)->original.c_str(), id.c_str()) == 0)
			return *it;
		
		if (isNumeric && SphereTask::IsNumeric((*it)->original) && SphereTask::ParseNumber((*it)->original) == numericId)
			return *it;
	}

	return NULL;
}
