#ifndef __FileSystem_H__
#define __FileSystem_H__
#pragma once
#include "common.h"

typedef std::vector<string> FileList;

class FileSystem
{
private:
	FileSystem(void);
	~FileSystem(void);

public:
	static bool Exists(string& path);
	static bool Exists(LPCTSTR path);
	static bool Delete(string& path);
	static bool Delete(LPCTSTR path);
	static bool Move(string& from, string& to);
	static bool Move(LPCTSTR from, LPCTSTR to);
	static bool Copy(string& from, string& to);
	static bool Copy(LPCTSTR from, LPCTSTR to);
	static int FindFiles(string directory, string pattern, bool recursive, FileList& result);

	static string CreateBackupName(string& path);
	static bool BackupExists(string& path);
	static bool CreateBackup(string& path);
};

#endif
