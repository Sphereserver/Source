// CSphereScriptUpgrade.cpp : Defines the entry point for the console application.
//
#include "SphereTask.h"

TCHAR ReadCharacter(void)
{
	string response;
	cin >> response;
	return (TCHAR)response.at(0);
}

void DoUpgrade(void)
{
	cout << _T("This tool will attempt to update your scripts and world saves for compatibility with Sphere's UO:SA support.") << std::endl;
	cout << std::endl;
	cout << _T("The upgrade process will take care of the following issues:") << std::endl;
	cout << _T("  - Convert multi definitions to use the new MULTIDEF syntax.") << std::endl;
	cout << _T("  - Modify non-base item definitions between the 04000-07fff range to use their defname only (a defname will be generated if none exists)") << std::endl;
	cout << _T("  - Update items in world saves to use any changed item ids") << std::endl;
	cout << std::endl;
	cout << _T("Please note that this program will not deal with any of the following, and you will need to update these manually if you have used them on your server:") << std::endl;
	cout << _T("  - Object properties that have been set to an item id (MORE1/MORE2/TAG./etc)") << std::endl;
	cout << _T("  - Scripts that reference an item id directly (e.g. <serv.itemdef.04000.name>)") << std::endl;
	cout << _T("  - There may be other scenarios that aren't addressed by this tool. Remember to check the results before running the updated scripts on a live server!") << std::endl;
	cout << std::endl;
	cout << _T("Before a file is changed, a backup of the script will be created with a '.backup' extension. If anything goes wrong during the upgrade procedure you should be able to use the 'Restore Backup Files' to easily revert changes. Making your own backup before running this tool is also recommended.") << std::endl;
	cout << std::endl;
	cout << _T("Once the upgrade is complete it is recommended that you compare the changed files to check that the changes are correct.") << std::endl;
	cout << std::endl;
	cout << _T("Do you want to continue with the upgrade? (Y/N)") << std::endl;

	TCHAR c = ReadCharacter();
	if (c != _T('Y') && c != _T('y'))
		return;

	// build list of tasks
	TaskHolder tasks;
	tasks.add(new PreCheckTask(&tasks));
	tasks.add(new UpdateMultisTask(&tasks));
	tasks.add(new UpdateBaseItemsTask(&tasks));
	tasks.add(new UpdateInheritedItemsTask(&tasks));
	tasks.add(new UpdateSavedItemsTask(&tasks));
	tasks.execute();
}

void DoRestore(void)
{
	cout << _T("Are you sure you want to restore your files from the backups made? (Y/N)") << std::endl;

	TCHAR c = ReadCharacter();
	if (c != _T('Y') && c != _T('y'))
		return;

	string paths[2] = { string(_T("./scripts")), string(_T("./save")) };
	int successCount = 0;
	int totalCount = 0;

	for (int i = 0; i < countof(paths); i++)
	{
		FileList files;
		FileSystem::FindFiles(paths[i], string(_T("*.scp.backup")), true, files);

		if (files.empty())
		{
			cout << _T("WARNING: No files found in '") << paths[i] << _T("'") << std::endl;
			continue;
		}

		totalCount += files.size();

		for (FileList::iterator it = files.begin(); it != files.end(); it++)
		{
			string originalFile = (*it).substr(0, (*it).length() - 7);

			if (FileSystem::Exists(originalFile))
				if (FileSystem::Delete(originalFile) == false)
					cout << _T("WARNING: Failed to delete existing file '") << originalFile.c_str() << _T("'") << std::endl;

			if (FileSystem::Move(*it, originalFile))
				successCount++;
			else
				cout << _T("ERROR: Failed to restore file '") << originalFile.c_str() << _T("'") << std::endl;
		}

		if (totalCount == 0)
			cout << _T("No backup files were found to restore.") << std::endl;
		else if (successCount != totalCount)
			cout << _T("Successfully restored ") << successCount << _T("/") << totalCount << _T(" file(s).") << std::endl;
		else
			cout << _T("Successfully restored ") << successCount << _T(" file(s).") << std::endl;
	}
}

#ifdef _WIN32
int _tmain(int argc, _TCHAR* argv[])
#else
int main(int argc, char* argv[])
#endif
{
	bool exit = false;

	while (exit == false)
	{
		cout << _T("Select an option:") << std::endl;
		cout << _T("  1. Upgrade scripts") << std::endl;
		cout << _T("  2. Restore backups") << std::endl;
		cout << _T("  X. Exit") << std::endl;
		cout << _T("-> ");

		switch (ReadCharacter())
		{
			case _T('1'):
				DoUpgrade();
				break;

			case _T('2'):
				DoRestore();
				break;

			case _T('X'):
			case _T('x'):
				exit = true;
				break;

			default:
				cout << _T("Unknown option selected.") << std::endl;
				break;
		}
	}

	return 0;
}

