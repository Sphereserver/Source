#include "FileSystem.h"

FileSystem::FileSystem(void)
{
}

FileSystem::~FileSystem(void)
{
}

bool FileSystem::Exists(string& path)
{
	return Exists(path.c_str());
}

bool FileSystem::Exists(LPCTSTR path)
{
	ifstream file(path);
	if (file.good() == false)
		return false;

	file.close();
	return true;
}

bool FileSystem::Delete(string& path)
{
	return Delete(path.c_str());
}

bool FileSystem::Delete(LPCTSTR path)
{
	return _tunlink(path) == 0;
}

bool FileSystem::Move(string& from, string& to)
{
	return Move(from.c_str(), to.c_str());
}

bool FileSystem::Move(LPCTSTR from, LPCTSTR to)
{
	return _trename(from, to) == 0;
}

bool FileSystem::Copy(string& from, string& to)
{
	return Copy(from.c_str(), to.c_str());
}

bool FileSystem::Copy(LPCTSTR from, LPCTSTR to)
{
	ifstream in(from, std::ios::binary);
	ofstream out(to, std::ios::binary);

	if (in.is_open() == false || out.is_open() == false)
		return false;

	out << in.rdbuf();
	return true;
}

int FileSystem::FindFiles(string directory, string pattern, bool recursive, FileList& results)
{
#ifdef _WIN32
	// ensure directory has trailing \ or /
	if (directory.at(directory.length()-1) != _T('\\') && directory.at(directory.length()-1) != _T('/'))
		directory.append(_T("/"));

	// build search directory
	TCHAR szDirectory[MAX_PATH];
	_tcscpy(szDirectory, directory.c_str());
	_tcscat(szDirectory, pattern.c_str());

	// get first result
	WIN32_FIND_DATA result;
	int count = 0;

	// search for matching files
	HANDLE hFiles = FindFirstFile(szDirectory, &result);
	if (hFiles != INVALID_HANDLE_VALUE)
	{
		do
		{
			if ((result.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == 0)
			{
				results.push_back(directory + result.cFileName);
				count++;
			}
		}
		while (FindNextFile(hFiles, &result) == TRUE);

		FindClose(hFiles);
	}

	// search through subdirectories
	if (recursive == true)
	{
		HANDLE hDirs = FindFirstFile((directory + _T("*")).c_str(), &result);
		if (hDirs != INVALID_HANDLE_VALUE)
		{
			do
			{
				if ((result.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) != 0 && recursive && result.cFileName[0] != _T('.'))
					count += FindFiles(directory + result.cFileName, pattern, recursive, results);
			}
			while (FindNextFile(hDirs, &result) == TRUE);
		}
	}

	return count;

#else

	// drop leading *, this linux implementation only matches the end of a file
	if (pattern.at(0) == _T('*'))
		pattern.erase(0, 1);

	DIR* dir = opendir(directory.c_str());
	if (dir == NULL)
		return 0;

	dirent* entry = NULL;
	int count = 0;

	while ((entry = readdir(dir)) != NULL)
	{
		if (entry->d_name[0] == _T('.'))
			continue;

		if ((entry->d_type & DT_DIR) == DT_DIR)
		{
			if (recursive)
				count += FindFiles(directory + "/" + entry->d_name, pattern, recursive, results);
		}
		else
		{
			string result(entry->d_name);
			if (pattern.empty() || ((result.length() >= pattern.length()) && (_tcsicmp(&(result.c_str()[result.length() - pattern.length()]), pattern.c_str()) == 0)))
				results.push_back(directory + "/" + result);
		}
	}

	closedir(dir);
	return count;

#endif
}

string FileSystem::CreateBackupName(string& path)
{
	return path + _T(".backup");
}

bool FileSystem::BackupExists(string& path)
{
	string backupName = CreateBackupName(path);
	return Exists(backupName);
}

bool FileSystem::CreateBackup(string& path)
{
	string backupPath = CreateBackupName(path);
	if (Exists(backupPath))
		return true;

	return Copy(path, backupPath);
}
