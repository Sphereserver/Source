using System;
using Ultima;

namespace SpyUO.Packets
{
	public sealed class LocalizedList
	{
		public static StringList List = new StringList( "ENU" );
	}
}