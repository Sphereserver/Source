This can view, parse, dump and patch an uop file.
View, parse and dump are done through an interface.

Patching (you can replace an existing file) through command line:
- file.exe <path_to_original_uop> <path_to_file_with_new_content> <id_indexblockheader> <id_fileindex>
- file.exe <path_to_original_uop> <path_to_file_with_new_content> <id_indexblockheader> <id_fileindex> <uncompressed>
-- <id_indexblockheader> and <id_fileindex>, lookup in the interface after a "Parse"
-- <uncompressed>, 0 for compressed - 1 uncompressed