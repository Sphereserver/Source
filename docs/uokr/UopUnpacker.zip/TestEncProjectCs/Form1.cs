using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Security.Cryptography;
using UOPDefine;

namespace UoKRUnpacker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private string HashToArray(byte[] theHash)
        {
            StringBuilder sbBuffer = new StringBuilder("0x");
            foreach (byte bSingle in theHash)
            {
                sbBuffer.AppendFormat("{0:X}", bSingle);
            }

            return sbBuffer.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ParseDump(false);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ParseDump(true);
        }

        private void ParseDump(bool bDump)
        {
            textBox1.Clear();

            DialogResult drFile = oFileDlgUopopen.ShowDialog(this);
            if (drFile != DialogResult.OK)
            {
                MessageBox.Show("File not selected!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            textBox1.AppendText("Parsing file " + oFileDlgUopopen.FileName + " ...\n");

            UopManager upIstance = UopManager.getIstance();
            upIstance.UopPath = oFileDlgUopopen.FileName;
            if ( !upIstance.Load() )
            {
                textBox1.AppendText("ERROR while parsing file " + oFileDlgUopopen.FileName + " !!!\n");
                return;
            }

            UOPFile uopToParse = upIstance.UopFile;

            {
                textBox1.AppendText("Done parsing.\n\n");
                textBox1.AppendText("Header: ");
                foreach (byte bCurrent in uopToParse.m_Header.m_variousData)
                    textBox1.AppendText(bCurrent.ToString() + " ");
                textBox1.AppendText("\n");
                textBox1.AppendText("UnkData: ");
                foreach (byte bCurrent in uopToParse.m_Header.m_Unknown)
                    textBox1.AppendText(bCurrent.ToString() + " ");
                textBox1.AppendText("\n");


                textBox1.AppendText("Total Index Blocks: " + uopToParse.m_Header.m_totalIndex.ToString() + "\n");
                int iCurrentindexDef = 0;
                foreach (UOPIndexBlockHeader aCurrent in uopToParse.m_Content)
                {
                    textBox1.AppendText("-- Index[" + iCurrentindexDef.ToString() + "] track files: " + aCurrent.m_Files.ToString() + "\n");
                    textBox1.AppendText("-- Index[" + iCurrentindexDef.ToString() + "] total compressed data: " + upIstance.SumOfDataInIndex(iCurrentindexDef).ToString() + " bytes\n");
                    int iCurrentIdef = 0;

                    if (!bDump)
                    {
                        foreach (UOPFileIndexDef bCurrent in aCurrent.m_ListIndex)
                        {
                            System.Threading.Thread.Sleep(1);

                            UOPFileData dCurrent = aCurrent.m_ListData[iCurrentIdef];

                            textBox1.AppendText("---- Index[" + iCurrentIdef.ToString() + "] def file comp/uncomp: " + bCurrent.m_LenghtCompressed.ToString() + "/" + bCurrent.m_LenghtUncompressed.ToString() + " \n");
                            textBox1.AppendText("---- Index[" + iCurrentIdef.ToString() + "] Unk1: " + String.Format("0x{0:X}", bCurrent.m_Unknown1) + " Unk2: " + String.Format("0x{0:X}", bCurrent.m_Unknown2) + "\n");
                            textBox1.AppendText("---- Index[" + iCurrentIdef.ToString() + "] OffsetOfThisBlock: " + String.Format("0x{0:X}", bCurrent.m_OffsetOfDataBlock) + " UnkData2: " + String.Format("0x{0:X}", dCurrent.m_Unknown) + " \n");

                            iCurrentIdef++;
                        }
                    }

                    iCurrentindexDef++;
                }

                if (!bDump)
                    return;

                textBox1.AppendText("\n\nStart dumping.\n");

                int iStartName = oFileDlgUopopen.FileName.LastIndexOf('\\') + 1;
                int iEndName = oFileDlgUopopen.FileName.LastIndexOf('.');

                string fileName = oFileDlgUopopen.FileName.Substring(iStartName, iEndName - iStartName);
                string newPath = Application.ExecutablePath.Substring(0, Application.ExecutablePath.LastIndexOf('\\'));
                newPath += @"\Unpacked";

                if (!Directory.Exists(newPath))
                    Directory.CreateDirectory(newPath);

                for (int i = 0; i < uopToParse.m_Content.Count; i++)
                {
                    UOPIndexBlockHeader aCurrent = uopToParse.m_Content[i];
                    for (int j = 0; j < aCurrent.m_ListIndex.Count; j++)
                    {
                        System.Threading.Thread.Sleep(1);

                        string sFileName = fileName + "_" + i.ToString() + "_" + j.ToString();

                        textBox1.AppendText("Dumping " + sFileName + " ... ");

                        UOPFileIndexDef uopFIDcurrent = aCurrent.m_ListIndex[j];
                        UOPFileData uopFDcurrent = aCurrent.m_ListData[j];

                        int iUncompressLength = ((int)(uopFIDcurrent.m_LenghtUncompressed));
                        byte[] bUnCompressData = new byte[iUncompressLength];
                        ZLibError zResult = Compressor.Decompress(bUnCompressData, ref iUncompressLength, uopFDcurrent.m_CompressedData, ((int)(uopFIDcurrent.m_LenghtCompressed)));
                        if (zResult == ZLibError.Okay)
                        {
                            using (FileStream fsWrite = File.Create(newPath + @"\" + sFileName + ".dat"))
                            {
                                using (BinaryWriter bwWrite = new BinaryWriter(fsWrite))
                                {
                                    bwWrite.Write(bUnCompressData);
                                }
                            }

                            textBox1.AppendText(" OK!\n");
                        }
                        else
                        {
                            using (FileStream fsWrite = File.Create(newPath + @"\" + sFileName + ".raw"))
                            {
                                using (BinaryWriter bwWrite = new BinaryWriter(fsWrite))
                                {
                                    bwWrite.Write(uopFDcurrent.m_CompressedData);
                                }
                            }

                            textBox1.AppendText(" ERROR! (" + zResult.ToString() + ")\n");
                        }
                    }
                }
            }

            GC.Collect();
            textBox1.AppendText("Done dumping.\n");
        }
    }
}