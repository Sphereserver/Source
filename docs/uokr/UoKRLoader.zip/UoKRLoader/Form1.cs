using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Diagnostics;
using System.IO;

namespace UoKRLoader
{
    public partial class Form1 : Form
    {
        enum ENCRYPTION_PATCH_TYPE
        {
            None = 0,
            Login,
            Game,
            Both,

            End
        }

        private static string[] arrsEncryptio_Patch_Type = { "Yes", "Remove Login", "Remove Game", "Remove Both" };

        public Form1()
        {
            InitializeComponent();

            this.cmbEncryption.SuspendLayout();
            this.cmbEncryption.Items.Clear();
            for (int i = 0; i < (int)ENCRYPTION_PATCH_TYPE.End; i++)
                this.cmbEncryption.Items.Add(arrsEncryptio_Patch_Type[i]);
            this.cmbEncryption.SelectedIndex = (int)ENCRYPTION_PATCH_TYPE.None;
            this.cmbEncryption.ResumeLayout();

            string tmpKrPath = Utility.GetExePath(Utility.UOKR_REGKEY);
            if (tmpKrPath != null)
            {
                this.txtUokrPath.Text = tmpKrPath;
            }

            if (File.Exists(Utility.LAUNCH_CFG))
            {
                string sConfig = null;

                using (StreamReader srRead = File.OpenText(Utility.LAUNCH_CFG))
                {
                    sConfig = srRead.ReadToEnd();
                }

                if ((sConfig != null) && (sConfig.Length != 0))
                {
                    sConfig = sConfig.Trim();
                    string[] sValues = sConfig.Split(new char[]{','});
                    this.txtIptopatch.Text = sValues[0].Trim();
                    this.nudPort.Value = Int32.Parse(sValues[1].Trim());
                    // -------------------------------------------------
                    this.cmbEncryption.SuspendLayout();
                    ENCRYPTION_PATCH_TYPE iSelected = (ENCRYPTION_PATCH_TYPE)Int32.Parse(sValues[2].Trim());
                    if (iSelected == ENCRYPTION_PATCH_TYPE.End)
                        iSelected = ENCRYPTION_PATCH_TYPE.None;
                    this.cmbEncryption.SelectedIndex = (int)iSelected;
                    this.cmbEncryption.ResumeLayout();
                }
            }
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            DialogResult drOpenFile = ofdUOKRClient.ShowDialog(this);

            if (drOpenFile == DialogResult.OK)
            {
                this.txtUokrPath.Text = ofdUOKRClient.FileName.Substring(0, ofdUOKRClient.FileName.LastIndexOf('\\'));
            }
        }

        private void btnLaunch_Click(object sender, EventArgs e)
        {
            if (nudPort.Value <= 0 || nudPort.Value > 65535)
            {
                MessageBox.Show("Invalid port: " + nudPort.Value.ToString() + " !", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            IPHostEntry host;

            try
            {
                host = Dns.GetHostEntry(txtIptopatch.Text.Trim());
            }
            catch (Exception)
            {
                MessageBox.Show("Invalid ip: " + txtIptopatch.Text + " !", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            IPAddress ip = host.AddressList[0];

            if (this.ckbRemind.Checked)
            {
                if ( this.txtIptopatch.Text.Length > 0 )
                {
                    using (StreamWriter srRead = File.CreateText(Utility.LAUNCH_CFG))
                    {
                        srRead.Write(this.txtIptopatch.Text.Trim() + "," + this.nudPort.Value.ToString() + "," + this.cmbEncryption.SelectedIndex.ToString());
                    }
                }
            }

            uint Port = (uint)nudPort.Value;
            byte[] newData = new byte[Utility.UOKR_IPDATA.Length];
            Utility.UOKR_IPDATA.CopyTo(newData, 0);
            newData[1] = ip.GetAddressBytes()[3];
            newData[3] = ip.GetAddressBytes()[1];
            newData[8] = ip.GetAddressBytes()[0];
            newData[14] = ip.GetAddressBytes()[2];
            newData[24] = (byte)(Port & 0xFF);
            newData[25] = (byte)((Port & 0xFF00) >> 8);
            newData[30] = (byte)(Port & 0xFF);
            newData[31] = (byte)((Port & 0xFF00) >> 8);

            Process prcTostart = new Process();
            prcTostart.StartInfo.FileName = this.txtUokrPath.Text + @"\" + Utility.UOKR_CLIENT;
            prcTostart.StartInfo.WorkingDirectory = this.txtUokrPath.Text;

            if (!prcTostart.Start())
            {
                MessageBox.Show("Cannot start the client !", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int iResultIP = Utility.Search(new ProcessStream((IntPtr)prcTostart.Id), Utility.UOKR_IPDATA);
            if (iResultIP == 0)
            {
                prcTostart.Close();
                MessageBox.Show("Cannot patch IP on the client !", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int iResultEncLogin = 0;
            int iResultEncGame = 0;
            ENCRYPTION_PATCH_TYPE encType = (ENCRYPTION_PATCH_TYPE)this.cmbEncryption.SelectedIndex;

            if ((encType == ENCRYPTION_PATCH_TYPE.Login) || (encType == ENCRYPTION_PATCH_TYPE.Both))
            {
                iResultEncLogin = Utility.Search(new ProcessStream((IntPtr)prcTostart.Id), Utility.UOKR_LOGDATA);
                if (iResultEncLogin == 0)
                {
                    prcTostart.Close();
                    MessageBox.Show("Cannot patch Login Encryption on the client !", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            if ((encType == ENCRYPTION_PATCH_TYPE.Game) || (encType == ENCRYPTION_PATCH_TYPE.Both))
            {
                iResultEncGame = Utility.Search(new ProcessStream((IntPtr)prcTostart.Id), Utility.UOKR_ENCDATA);
                if (iResultEncGame == 0)
                {
                    prcTostart.Close();
                    MessageBox.Show("Cannot patch Game Encryption on the client !", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            ProcessStream prcStream = new ProcessStream((IntPtr)prcTostart.Id);
            prcStream.Position = iResultIP;
            prcStream.Write(newData, 0, newData.Length);
            if ((encType == ENCRYPTION_PATCH_TYPE.Login) || (encType == ENCRYPTION_PATCH_TYPE.Both))
            {
                prcStream.Position = iResultEncLogin;
                prcStream.Write(Utility.UOKR_LOGPATCHDATA, 0, Utility.UOKR_LOGPATCHDATA.Length);
            }
            if ((encType == ENCRYPTION_PATCH_TYPE.Game) || (encType == ENCRYPTION_PATCH_TYPE.Both))
            {
                prcStream.Position = iResultEncGame;
                prcStream.Write(Utility.UOKR_ENCPATCHDATA, 0, Utility.UOKR_ENCPATCHDATA.Length);
            }
            prcStream.Close();

            System.Threading.Thread.Sleep(10);
            Close();
        }
    }
}