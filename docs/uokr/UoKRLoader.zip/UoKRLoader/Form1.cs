using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Diagnostics;
using System.IO;

namespace UoKRLoader
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            string tmpKrPath = Utility.GetExePath(Utility.UOKR_REGKEY);
            if (tmpKrPath != null)
            {
                this.txtUokrPath.Text = tmpKrPath;
            }

            if (File.Exists(Utility.LAUNCH_CFG))
            {
                string sConfig = null;

                using (StreamReader srRead = File.OpenText(Utility.LAUNCH_CFG))
                {
                    sConfig = srRead.ReadToEnd();
                }

                if ((sConfig != null) && (sConfig.Length != 0))
                {
                    sConfig = sConfig.Trim();
                    string[] sValues = sConfig.Split(new char[]{','});
                    this.txtIptopatch.Text = sValues[0].Trim();
                    this.nudPort.Value = Int32.Parse(sValues[1].Trim());
                }
            }
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            DialogResult drOpenFile = ofdUOKRClient.ShowDialog(this);

            if (drOpenFile == DialogResult.OK)
            {
                this.txtUokrPath.Text = ofdUOKRClient.FileName.Substring(0, ofdUOKRClient.FileName.LastIndexOf('\\'));
            }
        }

        private void btnLaunch_Click(object sender, EventArgs e)
        {
            if (nudPort.Value <= 0 || nudPort.Value > 65535)
            {
                MessageBox.Show("Invalid port: " + nudPort.Value.ToString() + " !", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            IPAddress ip;
            try
            {
                ip = IPAddress.Parse(txtIptopatch.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Invalid ip: " + txtIptopatch.Text + " !", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (this.ckbRemind.Checked)
            {
                if ( this.txtIptopatch.Text.Length > 0 )
                {
                    using (StreamWriter srRead = File.CreateText(Utility.LAUNCH_CFG))
                    {
                       srRead.Write(this.txtIptopatch.Text + "," + this.nudPort.Value.ToString());
                    }
                }
            }

            uint Port = (uint)nudPort.Value;
            byte[] newData = new byte[Utility.UOKR_IPDATA.Length];
            Utility.UOKR_IPDATA.CopyTo(newData, 0);
            newData[1] = ip.GetAddressBytes()[3];
            newData[3] = ip.GetAddressBytes()[1];
            newData[8] = ip.GetAddressBytes()[0];
            newData[14] = ip.GetAddressBytes()[2];
            newData[24] = (byte)(Port & 0xFF);
            newData[25] = (byte)((Port & 0xFF00) >> 8);
            newData[30] = (byte)(Port & 0xFF);
            newData[31] = (byte)((Port & 0xFF00) >> 8);

            Process prcTostart = new Process();
            prcTostart.StartInfo.FileName = this.txtUokrPath.Text + @"\" + Utility.UOKR_CLIENT;;
            prcTostart.StartInfo.WorkingDirectory = this.txtUokrPath.Text;

            if (!prcTostart.Start())
            {
                MessageBox.Show("Cannot start the client !", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int iResult = Utility.Search(new ProcessStream((IntPtr)prcTostart.Id), Utility.UOKR_IPDATA);
            if (iResult == 0)
            {
                prcTostart.Close();
                MessageBox.Show("Cannot patch the client !", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            ProcessStream prcStream = new ProcessStream((IntPtr)prcTostart.Id);
            prcStream.Position = iResult;
            prcStream.Write(newData, 0, newData.Length);
            prcStream.Close();

            System.Threading.Thread.Sleep(10);
            Close();
        }
    }
}